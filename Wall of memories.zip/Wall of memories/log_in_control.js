/* ============================================================
   log_in_control.js — Signup wizard controller
   ============================================================ */
(function () {
    'use strict';


    /* ============================================================
       1) TRANSLATIONS
       ============================================================ */
    const translations = {
        ar: {
            preview_label: "معاينة حية",
            preview_name_placeholder: "اسمك هنا",
            preview_role_placeholder: "الدور",
            form_title: "إنشاء البروفايل الشخصي",
            form_subtitle: "أكمل الخطوات التالية للانضمام إلى معرض الطلاب",
            draft_restored: "تم استرجاع مسودة محفوظة من زيارة سابقة ✓",
            step0_title: "تسجيل دخول الطلاب",
            btn_send_code: "إرسال الكود",
            lbl_code: "الكود المرسل إلى بريدك",
            btn_verify_code: "تأكيد الدخول",
            google_btn: "المتابعة عبر Google",
            or_divider: "أو",
            tab_signup: "حساب جديد",
            tab_login: "لدي حساب",
            lbl_email: "البريد الإلكتروني",
            lbl_password: "كلمة المرور",
            btn_create_account: "إنشاء الحساب",
            step1_title: "الخطوة 1 من 4: الهوية والدور",
            role_student: "طالب في الكوهورت",
            role_teacher: "معلم / ميسّر",
            lbl_fullname: "الاسم الكامل",
            lbl_bio: "نبذة عنك (Bio)",
            btn_next: "التالي ←",
            step2_title: "الخطوة 2 من 4: الربط الجغرافي والاجتماعي",
            lbl_city: "المدينة والدولة",
            btn_locate: "تحديد الدبوس على الخريطة",
            lbl_instagram: "انستقرام",
            lbl_linkedin: "لينكد إن",
            btn_prev: "→ السابق",
            step3_title: "الخطوة 3 من 4: التخصيص البصري والسمعي",
            lbl_avatar: "صورة البروفايل الشخصية",
            lbl_banner: "تصميم البنر",
            banner_default: "أزرق افتراضي",
            banner_custom: "لون مخصص",
            banner_image: "رفع صورة",
            lbl_song: "أغنية البروفايل",
            step4_title: "الخطوة 4 من 4: معرض الصور والفيديو",
            lbl_gallery: "صور الذكريات (من 1 إلى 15 صورة)",
            lbl_video_type: "نوع الفيديو",
            lbl_video_links: "روابط الفيديو (حتى 3 روابط)",
            video_first: "الفيديو الأول",
            video_second: "الفيديو الثاني",
            video_third: "الفيديو الثالث",
            video_hint: "الصق روابط يوتيوب أو Google Drive — جميعها اختيارية",
            btn_save: "حفظ وإنشاء البروفايل",
            required_field_msg: "هذا الحقل إلزامي",
            geo_denied_msg: "تعذّر الحصول على موقعك. تحقق من صلاحيات المتصفح.",
            profile_created_msg: "تم إنشاء البروفايل بنجاح! 🎉",
            profile_save_error_msg: "حدث خطأ أثناء حفظ البروفايل",
            gallery_min_msg: "الرجاء إضافة صورة واحدة على الأقل (بحد أقصى 15)",
            gallery_max_msg: "الحد الأقصى 15 صورة، تم الاحتفاظ بأول 15 صورة فقط",
            checking_link_msg: "جارٍ التحقق من الرابط...",
            link_valid_msg: "الرابط يبدو صحيحًا",
            link_invalid_msg: "الرابط غير صحيح أو الصيغة غير مدعومة",
            link_unverified_msg: "الصيغة صحيحة، لكن لا يمكن التأكد من وجود الحساب فعليًا من المتصفح",
            video_valid_msg: "تم التحقق: الفيديو موجود فعليًا",
            video_invalid_msg: "لم يتم العثور على فيديو بهذا الرابط",
            lbl_role_platform: "الدور في المنصة",
            banner_color1: "اللون الأول",
            banner_color2: "اللون الثاني",
            banner_direction: "اتجاه التدرج"
        },
        en: {
            preview_label: "Live preview",
            preview_name_placeholder: "Your name here",
            preview_role_placeholder: "Role",
            form_title: "Create your profile",
            form_subtitle: "Complete the steps below to join the students' gallery",
            draft_restored: "A saved draft from a previous visit was restored ✓",
            step0_title: "Student sign in",
            btn_send_code: "Send code",
            lbl_code: "Code sent to your email",
            btn_verify_code: "Verify & sign in",
            google_btn: "Continue with Google",
            or_divider: "or",
            tab_signup: "New account",
            tab_login: "I have an account",
            lbl_email: "Email",
            lbl_password: "Password",
            btn_create_account: "Create account",
            step1_title: "Step 1 of 4: Identity & role",
            role_student: "Cohort student",
            role_teacher: "Teacher / facilitator",
            lbl_fullname: "Full name",
            lbl_bio: "Short bio",
            btn_next: "Next →",
            step2_title: "Step 2 of 4: Location & social links",
            lbl_city: "City & country",
            btn_locate: "Place the pin on the map",
            lbl_instagram: "Instagram",
            lbl_linkedin: "LinkedIn",
            btn_prev: "← Back",
            step3_title: "Step 3 of 4: Visual & audio customization",
            lbl_avatar: "Profile picture",
            lbl_banner: "Banner design",
            banner_default: "Default blue",
            banner_custom: "Custom color",
            banner_image: "Upload image",
            lbl_song: "Profile song",
            step4_title: "Step 4 of 4: Gallery & video",
            lbl_gallery: "Memory photos (1 to 15)",
            lbl_video_type: "Video type",
            lbl_video_links: "Video links (up to 3)",
            video_first: "Video 1",
            video_second: "Video 2",
            video_third: "Video 3",
            video_hint: "Paste YouTube or Google Drive links — all optional",
            btn_save: "Save and create profile",
            required_field_msg: "This field is required",
            geo_denied_msg: "Could not get your location. Check your browser permissions.",
            profile_created_msg: "Profile created successfully! 🎉",
            profile_save_error_msg: "Something went wrong while saving your profile",
            gallery_min_msg: "Please add at least one photo (max 15)",
            gallery_max_msg: "Max 15 photos — only the first 15 were kept",
            checking_link_msg: "Checking link...",
            link_valid_msg: "Link looks valid",
            link_invalid_msg: "Invalid link or unsupported format",
            link_unverified_msg: "Format looks valid, but the account's existence can't be confirmed from the browser",
            video_valid_msg: "Verified: the video exists",
            video_invalid_msg: "No video found at this link",
            lbl_role_platform: "Role on the platform",
            banner_color1: "First color",
            banner_color2: "Second color",
            banner_direction: "Gradient direction"
        }
    };


    window.SIGNUP_TRANSLATIONS = translations;


    /* ============================================================
       2) SAFE STORAGE HELPERS
       ============================================================ */
    const { safeSetItem, safeGetItem, escapeHTML, safeHttpUrl, extractYouTubeId } = window.AmalaUtils;


    /* ============================================================
       3) THEME + LANGUAGE
       ============================================================ */
    const { applyTheme, applyLanguage, setupDropdowns } = window.AmalaUtils.createUI(translations, { emitEvent: false });
    window.applyTheme = applyTheme;
    window.applyLanguage = applyLanguage;


    document.addEventListener('DOMContentLoaded', () => {
        setupDropdowns();
        applyTheme(safeGetItem('preferred_theme', 'auto'));
        applyLanguage(safeGetItem('preferred_lang', 'ar'));
    });


    /* ============================================================
       4) MAIN WIZARD
       ============================================================ */
    document.addEventListener('DOMContentLoaded', async () => {
        const getSupabase = () => window.getSupabaseClient ? window.getSupabaseClient() : window.supabase;

        /* ---------- Sign-ups closed switch (CONFIG_APP.SIGNUPS_OPEN in core.js) ---------- */
        const SIGNUPS_OPEN = !(window.CONFIG_APP && window.CONFIG_APP.SIGNUPS_OPEN === false);
        const CLOSED_PAGE = 'signup_closed.html';
        const isAuthReturn = /[?&#](code|error|error_code|error_description|access_token)=/.test(window.location.search + window.location.hash);
        const memberMode = new URLSearchParams(window.location.search).has('member');
        // closed + not an existing member trying to sign in + not coming back from Google -> closed page
        if (!SIGNUPS_OPEN && !memberMode && !isAuthReturn) {
            window.location.replace(CLOSED_PAGE);
            return;
        }


        let map, marker;
        let currentAudio = null;
        let selectedSong = null;
        let searchDebounceTimer = null;
        window.USER_LOCATION = { lat: 31.9539, lng: 35.9106 };


        /* ---------- Step Navigation ---------- */
        window.goToStep = function (stepIndex) {
            const steps = document.querySelectorAll('.form-step');
            const progressBar = document.getElementById('progressBar');


            steps.forEach((step) => {
                const stepNum = parseInt(step.getAttribute('data-step'));
                step.classList.toggle('active-step', stepNum === stepIndex);
            });


            if (progressBar) {
                const totalSteps = steps.length - 1;
                const progressPercent = (stepIndex / totalSteps) * 100;
                progressBar.style.width = `${progressPercent}%`;
            }


            if (stepIndex === 2) {
                setTimeout(initMap, 200);
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        };


        /* ---------- Map ---------- */
        function initMap() {
            const mapElement = document.getElementById('mapPicker');
            if (!mapElement || typeof L === 'undefined') return;


            if (!map) {
                map = L.map('mapPicker').setView([window.USER_LOCATION.lat, window.USER_LOCATION.lng], 12);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap'
                }).addTo(map);


                marker = L.marker([window.USER_LOCATION.lat, window.USER_LOCATION.lng], { draggable: true }).addTo(map);


                marker.on('dragend', () => {
                    const pos = marker.getLatLng();
                    window.USER_LOCATION = { lat: pos.lat, lng: pos.lng };
                });


                map.on('click', (e) => {
                    marker.setLatLng(e.latlng);
                    window.USER_LOCATION = { lat: e.latlng.lat, lng: e.latlng.lng };
                });
            } else {
                map.invalidateSize();
            }
        }


        const locateBtn = document.getElementById('locateBtn');
        if (locateBtn) {
            locateBtn.addEventListener('click', () => {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition((pos) => {
                        const lat = pos.coords.latitude;
                        const lng = pos.coords.longitude;
                        window.USER_LOCATION = { lat, lng };
                        if (map && marker) {
                            map.setView([lat, lng], 14);
                            marker.setLatLng([lat, lng]);
                        }
                    }, () => {
                        window.alert((window.SIGNUP_TRANSLATIONS[window.CURRENT_LANG || 'ar'] || window.SIGNUP_TRANSLATIONS.ar).geo_denied_msg);
                    });
                }
            });
        }


        /* ---------- Live Preview ---------- */
        const fullNameInput = document.getElementById('fullName');
        const bioInput = document.getElementById('bio');
        const previewName = document.getElementById('previewName');
        const previewBio = document.getElementById('previewBio');
        const previewRole = document.getElementById('previewRole');
        const avatarInput = document.getElementById('avatarInput');
        const previewAvatarImg = document.getElementById('previewAvatarImg');
        const previewDisc = document.getElementById('previewDisc');
        const discPlayBtn = document.getElementById('discPlayBtn');


        if (fullNameInput && previewName) {
            fullNameInput.addEventListener('input', (e) => {
                const T = () => (window.SIGNUP_TRANSLATIONS[window.CURRENT_LANG || 'ar'] || window.SIGNUP_TRANSLATIONS.ar);
                previewName.textContent = e.target.value.trim() || T().preview_name_placeholder;
            });
        }


        if (bioInput && previewBio) {
            bioInput.addEventListener('input', (e) => {
                previewBio.textContent = e.target.value.trim();
            });
        }


        document.querySelectorAll('.role-card').forEach(card => {
            card.addEventListener('click', () => {
                document.querySelectorAll('.role-card').forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                if (previewRole) {
                    const text = card.querySelector('span')?.textContent;
                    previewRole.textContent = text || 'الدور';
                }
            });
        });


        if (avatarInput && previewAvatarImg) {
            avatarInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                        previewAvatarImg.src = event.target.result;
                    };
                    reader.readAsDataURL(file);
                }
            });
        }


        if (discPlayBtn) {
            discPlayBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const previewPlayBtn = document.getElementById('previewPlayBtn');
                if (previewPlayBtn) previewPlayBtn.click();
            });
        }


        /* ---------- Banner ---------- */
        const bannerOpts = document.querySelectorAll('.banner-opt');
        const customColorControls = document.getElementById('customColorControls');
        const bannerImageControls = document.getElementById('bannerImageControls');
        const bannerColor1 = document.getElementById('bannerColor1');
        const bannerColor2 = document.getElementById('bannerColor2');
        const bannerDirection = document.getElementById('bannerDirection');
        const bannerDirectionLabel = document.getElementById('bannerDirectionLabel');
        const bannerImgInput = document.getElementById('bannerImgInput');
        const previewBanner = document.getElementById('previewBanner');


        let currentBannerType = 'default';
        let bannerUploadedFile = null;


        function buildGradientCss() {
            const c1 = bannerColor1 ? bannerColor1.value : '#1d4ed8';
            const c2 = bannerColor2 ? bannerColor2.value : '#a855f7';
            const deg = bannerDirection ? bannerDirection.value : 135;
            return `linear-gradient(${deg}deg, ${c1} 0%, ${c2} 100%)`;
        }


        function updateBannerPreview() {
            if (!previewBanner) return;


            if (currentBannerType === 'default') {
                previewBanner.style.background = '#1d4ed8';
                previewBanner.style.backgroundImage = 'none';
            } else if (currentBannerType === 'custom') {
                previewBanner.style.background = buildGradientCss();
            } else if (currentBannerType === 'image') {
                if (bannerUploadedFile) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        previewBanner.style.background = `url('${e.target.result}') center/cover no-repeat`;
                    };
                    reader.readAsDataURL(bannerUploadedFile);
                }
            }
        }


        bannerOpts.forEach(opt => {
            opt.addEventListener('click', () => {
                bannerOpts.forEach(b => b.classList.remove('active'));
                opt.classList.add('active');


                currentBannerType = opt.getAttribute('data-banner-type');


                if (customColorControls) customColorControls.style.display = (currentBannerType === 'custom') ? 'block' : 'none';
                if (bannerImageControls) bannerImageControls.style.display = (currentBannerType === 'image') ? 'block' : 'none';


                updateBannerPreview();
            });
        });


        if (bannerColor1) bannerColor1.addEventListener('input', updateBannerPreview);
        if (bannerColor2) bannerColor2.addEventListener('input', updateBannerPreview);
        if (bannerDirection) {
            bannerDirection.addEventListener('input', () => {
                if (bannerDirectionLabel) bannerDirectionLabel.textContent = `${bannerDirection.value}°`;
                updateBannerPreview();
            });
        }


        if (bannerImgInput) {
            bannerImgInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    bannerUploadedFile = file;
                    updateBannerPreview();
                }
            });
        }


        updateBannerPreview();
        const selectedRoleSpanInit = document.querySelector('.role-card.selected span');
        if (previewRole && selectedRoleSpanInit) previewRole.textContent = selectedRoleSpanInit.textContent;


        /* ---------- Auth (Google only) ---------- */
        const AR = () => (window.CURRENT_LANG || 'ar') === 'ar';
        const L = (ar, en) => (AR() ? ar : en);
        const GOOGLE_PENDING_KEY = 'wiss_google_pending';
        const EDIT_VERIFIED_KEY = 'wiss_edit_verified';

        const authMsg = document.getElementById('authMsg');
        const googleBlock = document.getElementById('googleAuthBlock');
        const noticeBox = document.getElementById('accountNotice');
        const noticeText = document.getElementById('accountNoticeText');
        const noticeContinueBtn = document.getElementById('accountContinueBtn');
        const noticeSignOutBtn = document.getElementById('accountSignOutBtn');
        let noticeAction = null;

        function showAuthMsg(text, type) {
            if (!authMsg) return;
            authMsg.textContent = text || '';
            authMsg.className = 'auth-msg' + (type ? ' ' + type : '');
        }

        function showNotice(text, buttonLabel, action) {
            if (googleBlock) googleBlock.style.display = 'none';
            if (noticeBox) noticeBox.style.display = 'block';
            if (noticeText) noticeText.textContent = text;
            if (noticeContinueBtn) {
                noticeContinueBtn.textContent = buttonLabel;
                noticeContinueBtn.style.display = action ? '' : 'none';
            }
            if (noticeSignOutBtn) noticeSignOutBtn.textContent = L('تسجيل الخروج وتجربة حساب آخر', 'Sign out and try another account');
            noticeAction = action;
        }
        function hideNotice() {
            if (noticeBox) noticeBox.style.display = 'none';
            if (googleBlock) googleBlock.style.display = 'block';
            noticeAction = null;
        }
        if (noticeContinueBtn) noticeContinueBtn.addEventListener('click', () => { if (noticeAction) noticeAction(); });
        if (noticeSignOutBtn) noticeSignOutBtn.addEventListener('click', async () => {
            try { sessionStorage.removeItem(GOOGLE_PENDING_KEY); } catch (e) {}
            try { await getSupabase().auth.signOut(); } catch (e) {}
            hideNotice();
            showAuthMsg('');
        });

        // fresh = the person has just come back from Google in this visit
        async function afterAuth(user, fresh) {
            const supabase = getSupabase();
            const { data: existing, error } = await supabase
                .from('profiles').select('id').eq('id', user.id).maybeSingle();

            if (error) {
                showNotice(L('تعذّر التحقق من بروفايلك: ', 'Could not check your profile: ') + error.message,
                           L('إعادة المحاولة', 'Retry'), () => afterAuth(user, fresh));
                return;
            }
            if (existing) {
                // just proved identity with Google, so the edit page does not need to ask for a code again
                if (fresh) {
                    try { sessionStorage.setItem(EDIT_VERIFIED_KEY, JSON.stringify({ uid: user.id, t: Date.now() })); } catch (e) {}
                }
                window.location.href = 'edit_profile.html';
                return;
            }
            if (!SIGNUPS_OPEN) {
                try { await supabase.auth.signOut(); } catch (e) {}
                window.location.replace(CLOSED_PAGE);
                return;
            }
            if (fresh) { goToStep(1); return; }
            showNotice(
                L('أنت مسجّل الدخول بالحساب: ', 'You are signed in as: ') + (user.email || '') + '\n' +
                L('لا يوجد بروفايل لهذا الحساب بعد.', 'This account has no profile yet.'),
                L('إنشاء بروفايل لهذا الحساب', 'Create a profile for this account'),
                () => goToStep(1)
            );
        }

        // Google returns errors in the URL (e.g. sign-ups are closed): show a clear message instead
        (function showOAuthError() {
            const raw = (window.location.hash || '').replace(/^#/, '') || (window.location.search || '').replace(/^\?/, '');
            const params = new URLSearchParams(raw);
            const desc = params.get('error_description');
            if (!desc) return;
            try { sessionStorage.removeItem(GOOGLE_PENDING_KEY); } catch (e) {}
            const closed = /signups?[+\s]not[+\s]allowed|sign.?ups?[+\s](are[+\s])?disabled/i.test(desc) || params.get('error_code') === 'signup_disabled';
            if (closed) { window.location.replace(CLOSED_PAGE); return; }
            showAuthMsg(closed
                ? L('التسجيل مغلق حالياً. إن كان لديك بروفايل فادخل بنفس حساب Google الذي سجّلت به.',
                    'Sign-ups are currently closed. If you already have a profile, sign in with the Google account you used.')
                : L('تعذّر تسجيل الدخول عبر Google: ', 'Google sign-in failed: ') + desc.replace(/\+/g, ' '), 'error');
            history.replaceState(null, '', window.location.pathname);
        })();

        try {
            const supabase = getSupabase();
            if (supabase) {
                const { data: { session } } = await supabase.auth.getSession();
                if (session) {
                    let fresh = false;
                    try { fresh = sessionStorage.getItem(GOOGLE_PENDING_KEY) === '1'; sessionStorage.removeItem(GOOGLE_PENDING_KEY); } catch (e) {}
                    await afterAuth(session.user, fresh);
                }
            }
        } catch (err) {
            console.warn('Session check failed:', err.message);
        }

        const googleLoginBtn = document.getElementById('googleLoginBtn');
        if (googleLoginBtn) {
            googleLoginBtn.addEventListener('click', async () => {
                if (window.location.protocol === 'file:') {
                    showAuthMsg(L('تسجيل الدخول عبر Google لا يعمل عند فتح الملف مباشرة من الجهاز (file://). افتح الموقع من الرابط المنشور https://pip-project-e0df1-46313.web.app أو شغّل خادماً محلياً (مثل Live Server).',
                                  'Google sign-in does not work when the file is opened directly from disk (file://). Open the published site (https://pip-project-e0df1-46313.web.app) or run a local server (e.g. Live Server).'), 'error');
                    return;
                }
                googleLoginBtn.disabled = true;
                showAuthMsg('');
                try {
                    try { sessionStorage.setItem(GOOGLE_PENDING_KEY, '1'); } catch (e) {}
                    const { error } = await getSupabase().auth.signInWithOAuth({
                        provider: 'google',
                        options: { redirectTo: window.location.origin + window.location.pathname }
                    });
                    if (error) throw error;
                } catch (err) {
                    try { sessionStorage.removeItem(GOOGLE_PENDING_KEY); } catch (e) {}
                    showAuthMsg(L('تعذّر تسجيل الدخول عبر Google: ', 'Google sign-in failed: ') + err.message, 'error');
                    googleLoginBtn.disabled = false;
                }
            });
        }


        /* ---------- Validation Helpers ---------- */
        const T = () => (window.SIGNUP_TRANSLATIONS[window.CURRENT_LANG || 'ar'] || window.SIGNUP_TRANSLATIONS.ar);


        function setFieldStatus(statusEl, inputEl, state, message) {
            if (statusEl) {
                statusEl.textContent = message || '';
                statusEl.className = 'field-status' + (state ? ' ' + state : '');
            }
            if (inputEl) {
                inputEl.classList.remove('field-valid', 'field-invalid');
                if (state === 'valid') inputEl.classList.add('field-valid');
                if (state === 'invalid') inputEl.classList.add('field-invalid');
            }
        }


        function parseInstagramInput(value) {
            if (!value) return null;
            let v = value.trim();
            v = v.replace(/^https?:\/\/(www\.)?instagram\.com\//i, '').replace(/^@/, '').split('?')[0].replace(/\/+$/, '');
            return v;
        }
        function validateInstagramFormat(value) {
            const username = parseInstagramInput(value);
            if (!username) return { ok: false, username: '' };
            const ok = /^[a-zA-Z0-9._]{1,30}$/.test(username) && !username.startsWith('.') && !username.endsWith('.');
            return { ok, username };
        }


        function parseLinkedInInput(value) {
            if (!value) return null;
            let v = value.trim();
            v = v.replace(/^https?:\/\/([a-z]{2,3}\.)?linkedin\.com\/in\//i, '').split('?')[0].replace(/\/+$/, '');
            return v;
        }
        function validateLinkedInFormat(value) {
            const username = parseLinkedInInput(value);
            if (!username) return { ok: false, username: '' };
            const ok = /^[a-zA-Z0-9\-]{3,100}$/.test(username);
            return { ok, username };
        }


        function extractDriveId(url) {
            if (!url) return null;
            const patterns = [
                /drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/,
                /drive\.google\.com\/open\?id=([a-zA-Z0-9_-]+)/,
                /drive\.google\.com\/uc\?id=([a-zA-Z0-9_-]+)/,
                /drive\.google\.com\/drive\/folders\/([a-zA-Z0-9_-]+)/
            ];
            for (const p of patterns) {
                const m = url.match(p);
                if (m) return m[1];
            }
            return null;
        }


        async function checkYouTubeReal(url) {
            const id = extractYouTubeId(url);
            if (!id) return { ok: false, reason: 'format' };
            try {
                const res = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent('https://www.youtube.com/watch?v=' + id)}&format=json`);
                return { ok: res.ok, reason: res.ok ? 'verified' : 'not_found' };
            } catch (err) {
                return { ok: null, reason: 'network' };
            }
        }


        function checkDriveReal(url) {
            const id = extractDriveId(url);
            if (!id) return Promise.resolve({ ok: false, reason: 'format' });
            return new Promise((resolve) => {
                const img = new Image();
                let settled = false;
                const timer = setTimeout(() => {
                    if (!settled) { settled = true; resolve({ ok: null, reason: 'timeout' }); }
                }, 4000);
                img.onload = () => {
                    if (!settled) { settled = true; clearTimeout(timer); resolve({ ok: true, reason: 'verified' }); }
                };
                img.onerror = () => {
                    if (!settled) { settled = true; clearTimeout(timer); resolve({ ok: null, reason: 'unverifiable' }); }
                };
                img.src = `https://drive.google.com/thumbnail?id=${id}`;
            });
        }


        /* ---------- Instagram / LinkedIn validation ---------- */
        const instagramInput = document.getElementById('instagram');
        const instagramStatus = document.getElementById('instagramStatus');
        if (instagramInput) {
            instagramInput.addEventListener('blur', () => {
                const val = instagramInput.value.trim();
                if (!val) {
                    setFieldStatus(instagramStatus, instagramInput, 'invalid', T().required_field_msg);
                    return;
                }
                const { ok } = validateInstagramFormat(val);
                if (!ok) {
                    setFieldStatus(instagramStatus, instagramInput, 'invalid', T().link_invalid_msg);
                } else {
                    setFieldStatus(instagramStatus, instagramInput, 'unverified', T().link_unverified_msg);
                }
            });
        }


        const linkedinInput = document.getElementById('linkedin');
        const linkedinStatus = document.getElementById('linkedinStatus');
        if (linkedinInput) {
            linkedinInput.addEventListener('blur', () => {
                const val = linkedinInput.value.trim();
                if (!val) { setFieldStatus(linkedinStatus, linkedinInput, '', ''); return; }
                const { ok } = validateLinkedInFormat(val);
                if (!ok) {
                    setFieldStatus(linkedinStatus, linkedinInput, 'invalid', T().link_invalid_msg);
                } else {
                    setFieldStatus(linkedinStatus, linkedinInput, 'unverified', T().link_unverified_msg);
                }
            });
        }


        /* ---------- Video validation ---------- */
        document.querySelectorAll('.video-link-block').forEach(block => {
            const urlInput = block.querySelector('.video-url-input');
            const statusEl = block.querySelector('[data-video-status]');
            let debounceTimer = null;


            function getActiveType() {
                const activeTab = block.querySelector('.video-tab.active');
                return activeTab ? activeTab.getAttribute('data-vtype') : 'youtube';
            }


            block.querySelectorAll('.video-tab').forEach(tab => {
                tab.addEventListener('click', () => {
                    block.querySelectorAll('.video-tab').forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    if (urlInput && urlInput.value.trim()) runVideoCheck();
                });
            });


            async function runVideoCheck() {
                const val = urlInput.value.trim();
                if (!val) { setFieldStatus(statusEl, urlInput, '', ''); return; }
                setFieldStatus(statusEl, urlInput, 'checking', T().checking_link_msg);
                const type = getActiveType();
                if (type === 'youtube') {
                    const result = await checkYouTubeReal(val);
                    if (result.ok === true) setFieldStatus(statusEl, urlInput, 'valid', T().video_valid_msg);
                    else if (result.ok === false) setFieldStatus(statusEl, urlInput, 'invalid', T().video_invalid_msg);
                    else setFieldStatus(statusEl, urlInput, 'unverified', T().link_unverified_msg);
                } else {
                    const id = extractDriveId(val);
                    if (!id) { setFieldStatus(statusEl, urlInput, 'invalid', T().link_invalid_msg); return; }
                    const result = await checkDriveReal(val);
                    if (result.ok === true) setFieldStatus(statusEl, urlInput, 'valid', T().video_valid_msg);
                    else setFieldStatus(statusEl, urlInput, 'unverified', T().link_unverified_msg);
                }
            }


            if (urlInput) {
                urlInput.addEventListener('input', () => {
                    clearTimeout(debounceTimer);
                    debounceTimer = setTimeout(runVideoCheck, 600);
                });
            }
        });


        /* ---------- Bio validation ---------- */
        if (bioInput) {
            const bioStatus = document.getElementById('bioStatus');
            bioInput.addEventListener('blur', () => {
                if (!bioInput.value.trim()) {
                    setFieldStatus(bioStatus, bioInput, 'invalid', T().required_field_msg);
                } else {
                    setFieldStatus(bioStatus, bioInput, 'valid', '');
                }
            });
        }


        /* ---------- Avatar validation ---------- */
        if (avatarInput) {
            const avatarStatus = document.getElementById('avatarStatus');
            avatarInput.addEventListener('change', () => {
                if (avatarInput.files && avatarInput.files[0]) {
                    setFieldStatus(avatarStatus, avatarInput, 'valid', '');
                } else {
                    setFieldStatus(avatarStatus, avatarInput, 'invalid', T().required_field_msg);
                }
            });
        }


        /* ---------- Gallery ---------- */
        const galleryInputEl = document.getElementById('galleryInput');
        const galleryCountHint = document.getElementById('galleryCountHint');
        const galleryStatus = document.getElementById('galleryStatus');
        const MAX_GALLERY_PHOTOS = 15;


        function updateGalleryHint() {
            if (!galleryInputEl || !galleryCountHint) return;
            const count = galleryInputEl.files ? galleryInputEl.files.length : 0;
            galleryCountHint.textContent = `${count} / ${MAX_GALLERY_PHOTOS}`;
            galleryCountHint.classList.toggle('limit-reached', count >= MAX_GALLERY_PHOTOS);
        }


        if (galleryInputEl) {
            galleryInputEl.addEventListener('change', () => {
                if (galleryInputEl.files && galleryInputEl.files.length > MAX_GALLERY_PHOTOS) {
                    try {
                        const dt = new DataTransfer();
                        Array.from(galleryInputEl.files).slice(0, MAX_GALLERY_PHOTOS).forEach(f => dt.items.add(f));
                        galleryInputEl.files = dt.files;
                    } catch (err) {}
                    window.alert(T().gallery_max_msg);
                }
                updateGalleryHint();
                if (galleryInputEl.files && galleryInputEl.files.length > 0) {
                    setFieldStatus(galleryStatus, galleryInputEl, 'valid', '');
                } else {
                    setFieldStatus(galleryStatus, galleryInputEl, 'invalid', T().gallery_min_msg);
                }
            });
        }


        /* ---------- Step Validation ---------- */
        function validateStep(stepNum) {
            let valid = true;


            if (stepNum === 1) {
                if (!bioInput || !bioInput.value.trim()) {
                    setFieldStatus(document.getElementById('bioStatus'), bioInput, 'invalid', T().required_field_msg);
                    valid = false;
                }
                if (fullNameInput && !fullNameInput.value.trim()) {
                    fullNameInput.classList.add('field-invalid');
                    valid = false;
                } else if (fullNameInput) {
                    fullNameInput.classList.remove('field-invalid');
                }
            }


            if (stepNum === 2) {
                const val = instagramInput ? instagramInput.value.trim() : '';
                if (!val || !validateInstagramFormat(val).ok) {
                    setFieldStatus(instagramStatus, instagramInput, 'invalid', !val ? T().required_field_msg : T().link_invalid_msg);
                    valid = false;
                }
                const linkedinVal = linkedinInput ? linkedinInput.value.trim() : '';
                if (linkedinVal && !validateLinkedInFormat(linkedinVal).ok) {
                    setFieldStatus(linkedinStatus, linkedinInput, 'invalid', T().link_invalid_msg);
                    valid = false;
                }
            }


            if (stepNum === 3) {
                if (!avatarInput || !avatarInput.files || !avatarInput.files[0]) {
                    setFieldStatus(document.getElementById('avatarStatus'), avatarInput, 'invalid', T().required_field_msg);
                    valid = false;
                }
            }


            if (!valid) {
                window.alert(T().required_field_msg);
            }
            return valid;
        }


        /* ---------- Navigation Buttons ---------- */
        document.querySelectorAll('[data-action="next"]').forEach(btn => {
            btn.addEventListener('click', () => {
                const currentStep = btn.closest('.form-step');
                const currentStepNum = parseInt(currentStep.getAttribute('data-step'));
                if (!validateStep(currentStepNum)) return;
                goToStep(currentStepNum + 1);
            });
        });


        document.querySelectorAll('[data-action="prev"]').forEach(btn => {
            btn.addEventListener('click', () => {
                const currentStep = btn.closest('.form-step');
                const currentStepNum = parseInt(currentStep.getAttribute('data-step'));
                goToStep(currentStepNum - 1);
            });
        });


        /* ---------- Song Search ---------- */
        const songSearchInput = document.getElementById('songSearchInput');
        const songResults = document.getElementById('songResults');
        const songSelected = document.getElementById('songSelected');
        const selectedSongImg = document.getElementById('selectedSongImg');
        const selectedSongTitle = document.getElementById('selectedSongTitle');
        const selectedSongArtist = document.getElementById('selectedSongArtist');
        const removeSongBtn = document.getElementById('removeSongBtn');
        const previewPlayBtn = document.getElementById('previewPlayBtn');


        if (songSearchInput) {
            songSearchInput.addEventListener('input', (e) => {
                const query = e.target.value.trim();
                clearTimeout(searchDebounceTimer);


                if (query.length < 2) {
                    if (songResults) {
                        songResults.innerHTML = '';
                        songResults.style.display = 'none';
                    }
                    return;
                }


                searchDebounceTimer = setTimeout(async () => {
                    try {
                        const res = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(query)}&entity=song&limit=5`);
                        const data = await res.json();


                        if (!songResults) return;
                        songResults.innerHTML = '';
                        if (!data.results || data.results.length === 0) {
                            songResults.innerHTML = '<div class="song-item-empty">لم يتم العثور على نتائج</div>';
                            songResults.style.display = 'block';
                            return;
                        }


                        data.results.forEach(track => {
                            const item = document.createElement('div');
                            item.className = 'song-result-item';
                            const esc = escapeHTML;
                            item.innerHTML = `
                                <img src="${esc(safeHttpUrl(track.artworkUrl60))}" alt="">
                                <div class="song-meta">
                                    <div class="song-title">${esc(track.trackName)}</div>
                                    <div class="song-artist">${esc(track.artistName)}</div>
                                </div>
                            `;


                            item.addEventListener('click', () => {
                                selectedSong = {
                                    previewUrl: safeHttpUrl(track.previewUrl),
                                    title: track.trackName,
                                    artist: track.artistName,
                                    artwork: safeHttpUrl(track.artworkUrl100)
                                };
                                if (selectedSongImg) selectedSongImg.src = track.artworkUrl100;
                                if (selectedSongTitle) selectedSongTitle.textContent = track.trackName;
                                if (selectedSongArtist) selectedSongArtist.textContent = track.artistName;


                                songResults.style.display = 'none';
                                if (songSelected) songSelected.style.display = 'flex';
                                songSearchInput.value = '';


                                const previewSong = document.getElementById('previewSong');
                                if (previewSong) previewSong.textContent = `🎵 ${track.trackName} - ${track.artistName}`;


                                if (previewDisc) {
                                    previewDisc.style.backgroundImage = `url('${track.artworkUrl60}')`;
                                    previewDisc.classList.add('spinning');
                                }
                            });


                            songResults.appendChild(item);
                        });
                        songResults.style.display = 'block';
                    } catch (err) {
                        console.error("خطأ أثناء جلب الأغاني:", err);
                    }
                }, 400);
            });
        }


        if (previewPlayBtn) {
            previewPlayBtn.addEventListener('click', () => {
                if (!selectedSong) return;
                if (currentAudio && !currentAudio.paused) {
                    currentAudio.pause();
                    previewPlayBtn.textContent = '▶';
                    if (previewDisc) previewDisc.classList.remove('audio-on');
                } else {
                    if (currentAudio) currentAudio.pause();
                    currentAudio = new Audio(selectedSong.previewUrl);
                    currentAudio.play();
                    previewPlayBtn.textContent = '⏸';
                    if (previewDisc) previewDisc.classList.add('audio-on');
                    currentAudio.onended = () => {
                        previewPlayBtn.textContent = '▶';
                        if (previewDisc) previewDisc.classList.remove('audio-on');
                    };
                }
            });
        }


        if (removeSongBtn) {
            removeSongBtn.addEventListener('click', () => {
                if (currentAudio) {
                    currentAudio.pause();
                    currentAudio = null;
                }
                selectedSong = null;
                if (songSelected) songSelected.style.display = 'none';
                if (previewPlayBtn) previewPlayBtn.textContent = '▶';
                const previewSong = document.getElementById('previewSong');
                if (previewSong) previewSong.textContent = '';


                if (previewDisc) {
                    previewDisc.style.backgroundImage = '';
                    previewDisc.classList.remove('spinning', 'audio-on');
                }
            });
        }


        /* ---------- File Upload ---------- */
        async function uploadFileToStorage(file, bucket) {
            if (!file) return null;
            const supabase = getSupabase();
            const EXT_BY_MIME = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
            const fileExt = EXT_BY_MIME[file.type];
            if (!fileExt) { console.error('Unsupported file type:', file.type); return null; }
            const { data: { user: uploadUser } } = await supabase.auth.getUser();
            if (!uploadUser) { console.error('Not signed in'); return null; }
            const fileName = `${uploadUser.id}/${Date.now()}_${Math.random().toString(36).substring(2, 7)}.${fileExt}`;


            const { data, error } = await supabase.storage.from(bucket).upload(fileName, file);
            if (error) {
                console.error(`خطأ أثناء رفع الملف إلى ${bucket}:`, error.message);
                return null;
            }
            return data.path;
        }


        async function uploadGalleryFiles(fileList, bucket) {
            if (!fileList || fileList.length === 0) return [];
            const uploads = Array.from(fileList).map(file => uploadFileToStorage(file, bucket));
            const results = await Promise.all(uploads);
            return results.filter(path => path !== null);
        }


        /* ---------- Final Save ---------- */
        const handleProfileSave = async (e) => {
            if (e) e.preventDefault();
            if (currentAudio) currentAudio.pause();


            const galleryInputCheck = document.getElementById('galleryInput');
            const galleryOk = galleryInputCheck && galleryInputCheck.files && galleryInputCheck.files.length > 0;
            const step1Ok = validateStep(1);
            const step2Ok = validateStep(2);
            const step3Ok = validateStep(3);


            if (!galleryOk) {
                setFieldStatus(document.getElementById('galleryStatus'), galleryInputCheck, 'invalid', T().gallery_min_msg);
            }


            if (!step1Ok || !step2Ok || !step3Ok || !galleryOk) {
                window.alert(T().required_field_msg);
                if (!step1Ok) goToStep(1);
                else if (!step2Ok) goToStep(2);
                else if (!step3Ok || !galleryOk) goToStep(3);
                return;
            }


            const saveBtns = document.querySelectorAll('#saveProfileBtn, #submitBtn, [data-action="save"]');
            saveBtns.forEach(b => b.disabled = true);


            try {
                const supabase = getSupabase();
                const { data: { user } } = await supabase.auth.getUser();
                if (!user) throw new Error("المستخدم غير مسجل الدخول.");


                let avatarPath = null;
                if (avatarInput && avatarInput.files[0]) {
                    avatarPath = await uploadFileToStorage(avatarInput.files[0], 'avatars');
                }


                let bannerValue = '#1d4ed8';
                if (currentBannerType === 'custom') {
                    bannerValue = buildGradientCss();
                } else if (currentBannerType === 'image' && bannerUploadedFile) {
                    const uploadedBannerPath = await uploadFileToStorage(bannerUploadedFile, 'media');
                    if (uploadedBannerPath) bannerValue = uploadedBannerPath;
                }


                const galleryInput = document.getElementById('galleryInput');
                const galleryPaths = await uploadGalleryFiles(galleryInput?.files, 'media');


                const songPayload = selectedSong
                    ? { url: selectedSong.previewUrl, title: selectedSong.title, artist: selectedSong.artist, artwork: selectedSong.artwork }
                    : null;


                const videoLinks = Array.from(document.querySelectorAll('.video-link-block')).map(block => {
                    const url = block.querySelector('.video-url-input')?.value.trim() || '';
                    const type = block.querySelector('.video-tab.active')?.getAttribute('data-vtype') || 'youtube';
                    if (!url) return null;
                    if (type === 'gdrive' || type === 'drive') {
                        const id = extractDriveId(url);
                        return id ? { url: 'https://drive.google.com/file/d/' + id + '/view', type: 'gdrive' } : null;
                    }
                    const yid = extractYouTubeId(url);
                    return yid ? { url: 'https://www.youtube.com/watch?v=' + yid, type: 'youtube' } : null;
                }).filter(Boolean);


                const instagramParsed = validateInstagramFormat(document.getElementById('instagram')?.value.trim() || '');
                const linkedinRaw = document.getElementById('linkedin')?.value.trim() || '';
                const linkedinParsed = linkedinRaw ? validateLinkedInFormat(linkedinRaw) : null;


                const profilePayload = {
                    id: user.id,
                    full_name: document.getElementById('fullName')?.value.trim() || '',
                    role: document.querySelector('.role-card.selected')?.getAttribute('data-role-val') || 'student',
                    bio: document.getElementById('bio')?.value.trim() || '',
                    city: document.getElementById('city')?.value.trim() || null,
                    lat: window.USER_LOCATION.lat,
                    lng: window.USER_LOCATION.lng,
                    instagram: instagramParsed.username || null,
                    linkedin: linkedinParsed ? linkedinParsed.username : null,
                    avatar_url: avatarPath,
                    banner_style: bannerValue,
                    song_url: songPayload,
                    gallery: galleryPaths,
                    video_links: videoLinks,
                    updated_at: new Date().toISOString()
                };


                const { error } = await supabase.from('profiles').upsert(profilePayload);
                if (error) throw error;


                window.alert((window.SIGNUP_TRANSLATIONS[window.CURRENT_LANG || 'ar'] || window.SIGNUP_TRANSLATIONS.ar).profile_created_msg);
                setTimeout(() => { window.location.href = "gallery.html"; }, 800);


            } catch (err) {
                window.alert((window.SIGNUP_TRANSLATIONS[window.CURRENT_LANG || 'ar'] || window.SIGNUP_TRANSLATIONS.ar).profile_save_error_msg + ': ' + err.message);
                saveBtns.forEach(b => b.disabled = false);
            }
        };


        const wizardForm = document.getElementById('profileWizardForm');
        if (wizardForm) wizardForm.addEventListener('submit', handleProfileSave);


        const saveProfileBtnDirect = document.getElementById('saveProfileBtn');
        if (saveProfileBtnDirect) {
            saveProfileBtnDirect.addEventListener('click', (e) => {
                handleProfileSave(e);
            });
        }
    });
})();