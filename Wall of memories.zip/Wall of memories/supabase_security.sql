-- ============================================================================
-- supabase_security.sql  —  Amala GSD memories site
-- Run in the Supabase SQL editor (project scomyankrwvlquopqrxk), then test.
-- Written from the client code only: column/table names were inferred from the
-- JS files, so compare with your real schema before running. Idempotent.
-- NOT deployed with the site (listed in .vercelignore / firebase.json ignore).
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 0. Site settings (real sign-up switch, enforced on the server)
-- ---------------------------------------------------------------------------
create table if not exists public.app_settings (
  key   text primary key,
  value jsonb not null
);
insert into public.app_settings (key, value) values ('signups_open', 'true'::jsonb)
  on conflict (key) do nothing;
alter table public.app_settings enable row level security;
drop policy if exists app_settings_read on public.app_settings;
create policy app_settings_read on public.app_settings for select using (true);
-- (no insert/update/delete policies => only the dashboard / service role can change it)
-- To close sign-ups for real:  update public.app_settings set value='false' where key='signups_open';

-- ---------------------------------------------------------------------------
-- 1. profiles
-- ---------------------------------------------------------------------------
alter table public.profiles enable row level security;

drop policy if exists profiles_select_all  on public.profiles;
drop policy if exists profiles_insert_own  on public.profiles;
drop policy if exists profiles_update_own  on public.profiles;
drop policy if exists profiles_delete_own  on public.profiles;

-- The gallery and the map are public by design.
-- WARNING: if the 6-digit edit code (used by the `profile-code` edge function)
-- is stored in a column of this table, move it to a private table: every column
-- is readable by anyone through this policy.
create policy profiles_select_all on public.profiles for select using (true);

create policy profiles_insert_own on public.profiles for insert to authenticated
  with check (auth.uid() = id and role in ('student', 'teacher'));

create policy profiles_update_own on public.profiles for update to authenticated
  using (auth.uid() = id) with check (auth.uid() = id);

create policy profiles_delete_own on public.profiles for delete to authenticated
  using (auth.uid() = id);

-- Role / id can't be changed from the browser after the profile exists, and new
-- profiles can't be created while sign-ups are closed.
create or replace function public.profiles_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if coalesce((select (value)::text from public.app_settings where key = 'signups_open'), 'true') = 'false'
       and coalesce(auth.role(), '') <> 'service_role' then
      raise exception 'sign-ups are closed' using errcode = 'P0001';
    end if;
  elsif tg_op = 'UPDATE' then
    if coalesce(auth.role(), '') <> 'service_role' then
      new.role := old.role;
      new.id   := old.id;
    end if;
  end if;
  return new;
end $$;

drop trigger if exists trg_profiles_guard on public.profiles;
create trigger trg_profiles_guard before insert or update on public.profiles
  for each row execute function public.profiles_guard();

-- Basic input limits (raise the numbers if you need more room)
alter table public.profiles drop constraint if exists profiles_limits;
alter table public.profiles add constraint profiles_limits check (
  char_length(coalesce(full_name, '')) <= 120 and
  char_length(coalesce(bio, ''))       <= 2000 and
  char_length(coalesce(city, ''))      <= 120
) not valid;   -- "not valid": existing rows are not re-checked

-- ---------------------------------------------------------------------------
-- 2. profile_reactions  — counters can only change through the RPC below
-- ---------------------------------------------------------------------------
create unique index if not exists profile_reactions_profile_id_key
  on public.profile_reactions (profile_id);   -- fails if duplicate rows exist: merge them first

alter table public.profile_reactions enable row level security;
drop policy if exists reactions_select_all on public.profile_reactions;
drop policy if exists reactions_delete_own on public.profile_reactions;
drop policy if exists reactions_insert_any on public.profile_reactions;
drop policy if exists reactions_update_any on public.profile_reactions;

create policy reactions_select_all on public.profile_reactions for select using (true);
-- owners may clear the row when they delete their profile (core.js does this)
create policy reactions_delete_own on public.profile_reactions for delete to authenticated
  using (profile_id = auth.uid());
-- no insert/update policy => the browser can no longer write arbitrary numbers

create or replace function public.react_to_profile(p_profile_id uuid, p_old text, p_new text)
returns table (likes integer, laughs integer, sads integer, smiles integer)
language plpgsql security definer set search_path = public as $$
begin
  if p_old is not null and p_old not in ('like','laugh','sad','smile') then raise exception 'bad reaction'; end if;
  if p_new is not null and p_new not in ('like','laugh','sad','smile') then raise exception 'bad reaction'; end if;
  if not exists (select 1 from public.profiles where id = p_profile_id) then raise exception 'unknown profile'; end if;

  insert into public.profile_reactions (profile_id, likes, laughs, sads, smiles)
    values (p_profile_id, 0, 0, 0, 0) on conflict (profile_id) do nothing;

  return query
  update public.profile_reactions r set
    likes   = greatest(0, coalesce(r.likes,0)   + coalesce((p_new = 'like')::int, 0)  - coalesce((p_old = 'like')::int, 0)),
    laughs  = greatest(0, coalesce(r.laughs,0)  + coalesce((p_new = 'laugh')::int, 0) - coalesce((p_old = 'laugh')::int, 0)),
    sads    = greatest(0, coalesce(r.sads,0)    + coalesce((p_new = 'sad')::int, 0)   - coalesce((p_old = 'sad')::int, 0)),
    smiles  = greatest(0, coalesce(r.smiles,0)  + coalesce((p_new = 'smile')::int, 0) - coalesce((p_old = 'smile')::int, 0))
  where r.profile_id = p_profile_id
  returning r.likes, r.laughs, r.sads, r.smiles;
end $$;

revoke all on function public.react_to_profile(uuid, text, text) from public;
grant execute on function public.react_to_profile(uuid, text, text) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- 3. comments  — anonymous posting allowed, but bounded and rate-limited
-- ---------------------------------------------------------------------------
alter table public.comments enable row level security;
drop policy if exists comments_select_all on public.comments;
drop policy if exists comments_insert_any on public.comments;
drop policy if exists comments_delete_owner on public.comments;

create policy comments_select_all on public.comments for select using (true);
create policy comments_insert_any on public.comments for insert to anon, authenticated
  with check (
    char_length(btrim(comment_text)) between 1 and 500
    and (author_name is null or char_length(author_name) <= 60)
    and exists (select 1 from public.profiles p where p.id = profile_id)
  );
-- the profile owner can remove comments on their own profile
create policy comments_delete_owner on public.comments for delete to authenticated
  using (profile_id = auth.uid());

-- Server-side flood control (the 30 s limit in the browser is only cosmetic):
-- at most 5 new comments per profile per minute.
create or replace function public.comments_rate_limit()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.comments
       where profile_id = new.profile_id and created_at > now() - interval '1 minute') >= 5 then
    raise exception 'too many comments, try again shortly' using errcode = 'P0001';
  end if;
  return new;
end $$;
drop trigger if exists trg_comments_rate_limit on public.comments;
create trigger trg_comments_rate_limit before insert on public.comments
  for each row execute function public.comments_rate_limit();

-- ---------------------------------------------------------------------------
-- 4. Storage — buckets `avatars` and `media`
--    Files live under "<user id>/<file>" (both the sign-up and edit pages do this now).
-- ---------------------------------------------------------------------------
update storage.buckets
   set file_size_limit    = 5 * 1024 * 1024,
       allowed_mime_types = array['image/jpeg','image/png','image/webp']
 where id in ('avatars','media');

drop policy if exists "amala_public_read"   on storage.objects;
drop policy if exists "amala_owner_insert"  on storage.objects;
drop policy if exists "amala_owner_update"  on storage.objects;
drop policy if exists "amala_owner_delete"  on storage.objects;

create policy "amala_public_read" on storage.objects for select
  using (bucket_id in ('avatars','media'));

create policy "amala_owner_insert" on storage.objects for insert to authenticated
  with check (bucket_id in ('avatars','media') and (storage.foldername(name))[1] = auth.uid()::text);

create policy "amala_owner_update" on storage.objects for update to authenticated
  using      (bucket_id in ('avatars','media') and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id in ('avatars','media') and (storage.foldername(name))[1] = auth.uid()::text);

create policy "amala_owner_delete" on storage.objects for delete to authenticated
  using (bucket_id in ('avatars','media') and (storage.foldername(name))[1] = auth.uid()::text);

-- NOTE: files uploaded before this change that are NOT under "<user id>/" stay readable,
-- but their owners can no longer delete/replace them from the browser.

-- ---------------------------------------------------------------------------
-- 5. Reminder about the `profile-code` edge function (not in the repo)
--    * it must verify the caller's JWT and check the 6-digit code server-side;
--    * limit failed attempts per profile (e.g. 5 per 15 min), otherwise 10^6 codes can be brute-forced;
--    * the browser flag `wiss_edit_verified` is only UI — real protection is the policies above.
-- ---------------------------------------------------------------------------
