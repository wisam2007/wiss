#!/usr/bin/env python3
"""Pin CDN libraries to exact versions and add Subresource Integrity (SRI) hashes.

Run it ONCE from the project root, on a machine with internet access:
    python3 tools/pin_cdn.py            # rewrite the HTML files
    python3 tools/pin_cdn.py --dry-run  # only list what it would change

What it does for every <script src> / <link href> that points at cdn.jsdelivr.net or unpkg.com:
  1. resolves a floating version (e.g. @supabase/supabase-js@2) to the exact latest version,
  2. downloads the file and computes its sha384,
  3. writes  integrity="sha384-..." crossorigin="anonymous"  into the tag.
Re-run it whenever you intentionally bump a library version.
"""
import glob, hashlib, base64, json, re, sys, urllib.request

DRY = '--dry-run' in sys.argv
TAG = re.compile(r'<(script|link)\b[^>]*?\b(?:src|href)="(https://(?:cdn\.jsdelivr\.net/npm|unpkg\.com)/[^"]+)"[^>]*>')
VER = re.compile(r'^(https://(?:cdn\.jsdelivr\.net/npm|unpkg\.com))/((?:@[^/@]+/)?[^/@]+)@([^/]+)(/.*)$')

def fetch(url):
    with urllib.request.urlopen(url, timeout=30) as r:
        return r.read()

def exact(url):
    m = VER.match(url)
    if not m:
        return url
    host, pkg, ver, rest = m.groups()
    if not re.fullmatch(r'\d+\.\d+\.\d+', ver):
        meta = json.loads(fetch(f'https://cdn.jsdelivr.net/npm/{pkg}@{ver}/package.json'))
        ver = meta['version']
    return f'{host}/{pkg}@{ver}{rest}'

cache = {}
for path in sorted(glob.glob('*.html')):
    raw = open(path, 'rb').read().decode('utf-8')
    def fix(m):
        tag, old = m.group(0), m.group(2)
        new = exact(old)
        if new not in cache:
            data = fetch(new)
            cache[new] = 'sha384-' + base64.b64encode(hashlib.sha384(data).digest()).decode()
        tag = tag.replace(old, new)
        tag = re.sub(r'\s+(integrity|crossorigin)="[^"]*"', '', tag)
        tag = re.sub(r'(\s*/?>)$', f' integrity="{cache[new]}" crossorigin="anonymous"\\1', tag)
        print(f'{path}: {new}\n    {cache[new]}')
        return tag
    out = TAG.sub(fix, raw)
    if out != raw and not DRY:
        open(path, 'wb').write(out.encode('utf-8'))
print('done' + (' (dry run, nothing written)' if DRY else ''))
