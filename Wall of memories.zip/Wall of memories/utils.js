/* ============================================================
   utils.js — shared helpers (load BEFORE core.js and page scripts)
   ============================================================ */
(function () {
    'use strict';

    const U = {};

    /* ---- Storage (never throws) ---- */
    U.safeGetItem = function (key, fallback) {
        try { return localStorage.getItem(key) || fallback; } catch (e) { return fallback; }
    };
    U.safeSetItem = function (key, value) {
        try { localStorage.setItem(key, value); } catch (e) {}
    };
    U.safeRemoveItem = function (key) {
        try { localStorage.removeItem(key); } catch (e) {}
    };

    /* ---- HTML escaping (safe for text AND quoted attribute values) ---- */
    U.escapeHTML = function (value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/`/g, '&#96;');
    };

    /* ---- URL helpers ---- */
    // Returns the URL only if it is http(s); otherwise ''.
    U.safeHttpUrl = function (url) {
        if (!url) return '';
        try {
            const u = new URL(String(url).trim(), window.location.href);
            return (u.protocol === 'https:' || u.protocol === 'http:') ? u.href : '';
        } catch (e) { return ''; }
    };

    U.extractYouTubeId = function (url) {
        if (!url) return null;
        const m = String(url).match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:[^#]*&)?v=|embed\/|shorts\/))([A-Za-z0-9_-]{11})/);
        return m ? m[1] : null;
    };

    // Drive IDs are strictly [A-Za-z0-9_-]
    U.extractDriveFileId = function (url) {
        if (!url) return null;
        const s = String(url);
        const d = s.match(/\/d\/([A-Za-z0-9_-]+)/);
        if (d) return d[1];
        const q = s.match(/[?&]id=([A-Za-z0-9_-]+)/);
        return q ? q[1] : null;
    };

    /* ---- CSS value guards ---- */
    // Accepts only: #hex colour, or linear-gradient(Ndeg, #hex 0%, #hex 100%) (also without percentages).
    U.safeBackground = function (value) {
        if (!value || typeof value !== 'string') return '';
        const v = value.trim();
        if (/^#[0-9a-fA-F]{3,8}$/.test(v)) return v;
        if (/^linear-gradient\(\s*-?\d{1,3}deg\s*,\s*#[0-9a-fA-F]{3,8}(\s+\d{1,3}%)?\s*,\s*#[0-9a-fA-F]{3,8}(\s+\d{1,3}%)?\s*\)$/i.test(v)) return v;
        return '';
    };

    /* ---- Theme / language / dropdowns (shared by core.js and log_in_control.js) ----
       Elements are looked up at call time, so the factory can run before the DOM is ready.
       options.emitEvent: dispatch a 'languageChanged' CustomEvent after each language switch. */
    U.createUI = function (translations, options) {
        const emitEvent = !!(options && options.emitEvent);
        const $ = (id) => document.getElementById(id);

        function applyTheme(themeChoice) {
            let effectiveTheme = themeChoice;
            if (themeChoice === 'auto') {
                const hour = new Date().getHours();
                effectiveTheme = (hour >= 6 && hour < 18) ? 'light' : 'dark';
            }
            if (effectiveTheme === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
            else document.documentElement.removeAttribute('data-theme');

            const celestialToggle = $('celestialToggle');
            if (celestialToggle) {
                celestialToggle.classList.toggle('is-dark', effectiveTheme === 'dark');
                celestialToggle.classList.toggle('is-auto', themeChoice === 'auto');
            }
            const themeDropdown = $('themeDropdown');
            if (themeDropdown) {
                themeDropdown.querySelectorAll('.dropdown-item').forEach((item) => {
                    item.classList.toggle('active', item.getAttribute('data-theme-val') === themeChoice);
                });
            }
            U.safeSetItem('preferred_theme', themeChoice);
        }

        function applyLanguage(lang) {
            if (!translations[lang]) lang = 'ar';
            document.documentElement.setAttribute('lang', lang);
            document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
            const label = $('currentLangLabel');
            if (label) label.textContent = lang.toUpperCase();

            // Dictionary values are static strings from our own source (some contain <br>/<b>), never user data.
            document.querySelectorAll('[data-i18n]').forEach((el) => {
                const value = translations[lang][el.getAttribute('data-i18n')];
                if (!value) return;
                if (el.tagName === 'INPUT' && el.hasAttribute('placeholder')) el.setAttribute('placeholder', value);
                else el.innerHTML = value;
            });
            document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
                const value = translations[lang][el.getAttribute('data-i18n-placeholder')];
                if (value) el.setAttribute('placeholder', value);
            });
            document.querySelectorAll('[data-i18n-title]').forEach((el) => {
                const value = translations[lang][el.getAttribute('data-i18n-title')];
                if (value) el.setAttribute('title', value);
            });
            const langDropdown = $('langDropdown');
            if (langDropdown) {
                langDropdown.querySelectorAll('.dropdown-item').forEach((item) => {
                    item.classList.toggle('active', item.getAttribute('data-lang-val') === lang);
                });
            }
            U.safeSetItem('preferred_lang', lang);
            window.CURRENT_LANG = lang;
            if (emitEvent) window.dispatchEvent(new CustomEvent('languageChanged', { detail: { lang } }));
        }

        function setupDropdowns() {
            const themeBtn = $('themeDropdownBtn');
            const themeContent = document.querySelector('#themeDropdown .dropdown-content');
            const langBtn = $('langDropdownBtn');
            const langContent = document.querySelector('#langDropdown .dropdown-content');

            if (themeBtn && themeContent) {
                themeBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (langContent) langContent.classList.remove('show');
                    themeContent.classList.toggle('show');
                });
                document.querySelectorAll('#themeDropdown .dropdown-item').forEach((item) => {
                    item.addEventListener('click', () => {
                        applyTheme(item.getAttribute('data-theme-val'));
                        themeContent.classList.remove('show');
                    });
                });
            }
            if (langBtn && langContent) {
                langBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (themeContent) themeContent.classList.remove('show');
                    langContent.classList.toggle('show');
                });
                document.querySelectorAll('#langDropdown .dropdown-item').forEach((item) => {
                    item.addEventListener('click', () => {
                        applyLanguage(item.getAttribute('data-lang-val'));
                        langContent.classList.remove('show');
                    });
                });
            }
            document.addEventListener('click', () => {
                if (themeContent) themeContent.classList.remove('show');
                if (langContent) langContent.classList.remove('show');
            });
        }

        return { applyTheme, applyLanguage, setupDropdowns };
    };

    window.AmalaUtils = U;
})();
